<template>
    <div>
        <h1 class="text-2xl uppercase font-bold">Poll Page</h1>
        <p class="text-red-500">No poll available! at the moment.</p>
    </div>
</template>
<script setup>

</script>